
// Script for handling shop page functionalities
    